
/**
 * Write a description of class Cheese here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cheese extends Toppings implements Cuttable
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void place()
    {
        // put your code here
        System.out.println("You have placed cheese on your pizza.");
    }
    
    public void cut()
    {
        System.out.println("The cheese is not cuttable!");
    }
}
