
/**
 * Write a description of class Sausage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sausage extends Toppings implements Cuttable
{
    // instance variables - replace the example below with your own
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void place()
    {
        // put your code here
        System.out.println("You have placed sausage on your pizza.");
    }
    
    public void cut()
    {
        System.out.println("You have cut the sausage into many links!");
    }
}
