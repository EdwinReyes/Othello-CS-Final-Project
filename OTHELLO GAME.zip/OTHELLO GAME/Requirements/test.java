
import java.util.*;

/**
 * Write a description of class test here.
 * 
 * @Kory Borromeo 
 * @Requirements
 */
public class test
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  none
     * @return    none
     * @
     */
    public static void main(String args[])
    {
        // put your code here
        int userChoice = 0;
        ArrayList <Toppings> top = new ArrayList <Toppings> (); 
        ArrayList <Cuttable> cut = new ArrayList <Cuttable> ();
        Scanner in = new Scanner(System.in);
        
        Cuttable pepperoni = new Pepperoni();
        Cuttable che = new Cheese();
        Cuttable sau = new Sausage();
        Cuttable pineapple = new Pineapple();
        cut.add(pepperoni);
        cut.add(che);
        cut.add(sau);
        cut.add(pineapple);
        
        Toppings pep = new Pepperoni();
        Toppings cheese = new Cheese();
        Toppings sausage = new Sausage();
        Toppings pin = new Pineapple();
        top.add(pep);
        top.add(cheese);
        top.add(sausage);
        top.add(pin);
        
        // traverses through the topping array and displays the place method
        for ( int x = 0; x < top.size(); x++ )
        {
            top.get(x).place();
        } // ends the for loop
        
        System.out.println("Choose which toppings that you want to place and cut.");
        while ( userChoice != 5 )
        {
            System.out.println("1. Place and cut pepperoni.");
            System.out.println("2. Place and cut cheese.");
            System.out.println("3. Place and cut sausage.");
            System.out.println("4. Place and cut pineapple.");
            System.out.println("5. Done");
            userChoice = in.nextInt();  // user input
            
            if (userChoice <= 4)
            {
                cut.get(userChoice - 1).cut(); 
                top.get(userChoice - 1).place();    // it is subtracted by one since an array starts with 0
            } // if the user input entered is 4 or less it calls top and cut arrays 
            else if (userChoice == 5)
            {
                System.out.println("You have cut and placed the toppings that you desired!");
            } // if user inputs 5 the program is closed
            else if (userChoice > 5)
            {
                System.out.println("Please select a valid number.");
            } // input validation
        } // ends the while loop
    } // ends the method
} // ends the class test
