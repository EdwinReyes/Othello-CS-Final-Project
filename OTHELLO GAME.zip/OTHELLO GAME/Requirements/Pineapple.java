
/**
 * Write a description of class Pineapple here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pineapple extends Toppings implements Cuttable
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void place()
    {
        System.out.println("You have placed pineapple on your pizza.");
        
    }
    
    public void cut()
    {
        System.out.println("You have cut the pineapple into many chunks!");
        
    }
}
