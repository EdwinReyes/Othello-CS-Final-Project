
/**
 * Abstract class Toppings - write a description of the class here
 * 
 * @author Kory Borromeo
 * @version Requirements
 */
public abstract class Toppings
{
    public abstract void place();
}
