
/**
 * Write a description of interface Eat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Cuttable
{
    public void cut();
}
