
/**
 * Write a description of class Pepperoni here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pepperoni extends Toppings implements Cuttable
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void place()
    {
        // put your code here
        System.out.println("You have placed pepperoni on your pizza.");
    }
    
    public void cut()
    {
        System.out.println("You have cut the pepperoni into many slices!");
    }
}
